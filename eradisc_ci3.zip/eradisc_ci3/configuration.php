<?php	
	class SConfig{
		var $_url_unlock = 'admin';
	}