<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();		
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
	}

	public function index(){

	}

	public function login(){
		if($this->session->userdata('admin_access') == TRUE){

			$this->load->view('l_admin');
		}
		else{
			echo 'ORA BISA SON!!!!';
		}
	}

	public function login_redirect(){
		$this->session->set_userdata('admin_access', FALSE);
		redirect('/admin/login');		
	}
}