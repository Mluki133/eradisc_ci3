<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Form Login!</title>
	
</head>
<body>
	<form>
		<h1>Form Login</h1>
		<label>Username</label> <input type="text" name="name" /><br />
		<label>Password</label> <input type="password" name="password" /><br />
		<input type="submit" value="Login!" />
	</form>
</body>
</html>